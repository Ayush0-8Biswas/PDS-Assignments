#include<stdio.h>

int main()
{
  int m, n, G[100][100], A[100], largest_group=0, Isgroup, size, CurrentGroup[100], i, j, k;
  for(i=0; i<n; i++)
  {
    A[i]=0;
    CurrentGroup[i]=0;
  }
  for(i=0; i<n; i++)
    for(j=0; j<n; j++)
      G[i][j]=0;
  printf("How many people and friendships? ");
  scanf("%d%d", &n, &m);
  for(i=0; i<m; i++)
  {
    printf("Enter the two guests participating in friendship %d: ", i+1);
    scanf("%d%d", &j, &k);
    G[j-1][k-1]=1;
    G[k-1][j-1]=1;
  }
  while(1)
  {  
    for(i=n-1; i>=0 && A[i]==1; i--)
      A[i]=0;
    if(i==-1)
      break;
    A[i]=1;
    size=0;
    for(i=0; i<n; i++)
      if(A[i]==1)
        size++;
    if(size<=largest_group)
      continue;
    Isgroup=1;
    for(i=0; i<n-1; i++)
    {
      for(j=i+1; j<n; j++)
      {
        if(A[i]==1 && A[j]==1 && G[i][j]==0)
        { 
          Isgroup=0;
          break;
        }
      }
      if(Isgroup==0)
        break;
    }
    if(Isgroup==1 && size > largest_group)
    {
      largest_group=size;
      for(i=0; i<n; i++)
        CurrentGroup[i]=A[i];
    }
  }
  printf("Largest friendship group:\n");
  for(i=0; i<n; i++)
    if(CurrentGroup[i]==1)
      printf("%d ", i+1);
  printf("\nSize=%d\n", largest_group);
  return 0;
}




