#include<stdio.h>

struct card
{
  char suit;
  char num;
};

char clubs0[]    = {0xE2, 0x99, 0xA3, 0};
char diamonds0[] = {0xE2, 0x99, 0xA6, 0};
char hearts0[]   = {0xE2, 0x99, 0xA5, 0};
char spades0[]   = {0xE2, 0x99, 0xA0, 0};

int less(struct card P, struct card Q)
{
  if(P.suit < Q.suit)
    return 1;
  if(P.suit > Q.suit)
    return 0;
  if(P.num>='2' && P.num<='9')
  {
    if(!(Q.num>='2' && Q.num<='9'))
      return 1;
    else  if(P.num < Q.num)
            return 1;
  }
  if(Q.num>='2' && Q.num<='9')
    return 0;
  if(P.num=='J')
    if(Q.num!='J')
      return 1;
  if(P.num=='Q')
    if(Q.num=='K' || Q.num=='A')
      return 1;
  if(P.num=='K' && Q.num=='A')
    return 1;
  return 0;
}

void swap(struct card P[], int i, int j)
{
  (P[i].num)=(P[i].num)-(P[j].num);
  (P[j].num)=(P[i].num)+(P[j].num);
  (P[i].num)=(P[j].num)-(P[i].num);
  (P[i].suit)=(P[i].suit)-(P[j].suit);
  (P[j].suit)=(P[i].suit)+(P[j].suit);
  (P[i].suit)=(P[j].suit)-(P[i].suit);
}

/*void swap(struct card *A, struct card *B)
{
  (A->num)=(A->num)-(B->num);
  (B->num)=(A->num)+(B->num);
  (A->num)=(B->num)-(A->num);
  (A->suit)=(A->suit)-(B->suit);
  (B->suit)=(A->suit)+(B->suit);
  (A->suit)=(B->suit)-(A->suit);
}*/

void Printsuit(char suit)
{
  switch(suit)
  {
    case 'C':
      printf("%s",clubs0);
      break;
    case 'D':
      printf("%s",diamonds0);
      break;
    case 'H':
      printf("%s",hearts0);
      break;
    case 'S':
      printf("%s",spades0);
  }
}

int main()
{
  int size=0, i=0, j=0;
  int numC=0, numD=0, numH=0, numS=0;
  char s[200];
  struct card P[52];
  printf("Enter the sequence of cards: ");
  scanf("%[^\n]s", s);
  if(s[0]=='\0')
  {
    printf("Empty sequence.");
    return 0;
  }
  while(1)
  {
     P[size].num=s[i++];  
     P[size++].suit=s[i++];
     if(s[i]=='\0')
       break;
     i++;
  }
  for(i=0; i<size-1; i++)
    for(j=i+1; j< size; j++)
      if(less(P[j], P[i]) == 1)
        swap(P, i, j);
  for(i=0; i<size-1; i++)
  {
    printf("%c",P[i].num);
    Printsuit(P[i].suit);
    printf(" ");
  }
  printf("%c", P[size-1].num);
  Printsuit(P[i].suit);
  printf("\n");
  return 0;
}  
