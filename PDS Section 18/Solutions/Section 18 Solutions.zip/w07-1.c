#include<stdio.h>

int Eval(int A[], int C[], int m)
{
  int true=1, i;
  for(i=0; i<3*m; i+=3)
    if((   ((C[i]>0)?A[C[i]-1]:(1-A[-C[i]-1])) ||  ((C[i+1]>0)?A[C[i+1]-1]:(1-A[-C[i+1]-1])) || ((C[i+2]>0)?A[C[i+2]-1]:(1-A[-C[i+2]-1])) )==0)
      return 0;
  return 1;
}

int main()
{
  int m, n, i, A[8], C[1000];
  printf("Questions:\n\n1)  Does the tour last for more than a week?\n2)  Does the tour involve a lot of physical activities like hiking?\n3)  Is the location of the tour a hill station?\n4)  Is the cost per head more than 15000 INR?\n5)  Are all the meals arranged by the tour manager?\n6)  Are hotel rooms in the ground floor ensured for elderly people?\n7)  Are the hotel rooms air-conditioned?\n8)  Are wheelchairs arranged for physically challenged tourists?\n\n");
  printf("Enter number of groups: "); // Assume that m>0
  scanf("%d",&m);
  for(i=0; i<8; i++)
    A[i]=0;
  for(i=0; i<3*m; i+=3)
  {
    printf("Enter the three preferences of group %d: ", i/3+1);
    scanf("%d%d%d", &C[i], &C[i+1], &C[i+2]);
  }
  for(;;)
  {
    if(Eval(A, C, m))
    {
      printf("Answers:\n");
      for(i=0; i<7; i++)
      {
        printf("%d: ", i+1);
        (A[i]==1)? printf("YES, ") : printf("NO, ");
      }
      printf("8: ");
      (A[7]==1)? printf("YES\n") : printf("NO\n");
      return 0;
    }
    for(i=7; i>=0 && A[i]==1; i--)
      A[i]=0;
    if(i==-1)
    {
      printf("The questions cannot be answered.\n");
      return 0;
    }
    A[i]=1;
  }
}
