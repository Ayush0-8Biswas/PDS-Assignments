#include<stdio.h>

int main()
{
  int a;
  printf("Enter a positive integer: ");
  scanf("%d",&a);
  a=(a%10)*1000+(a/10);
  printf("%4d\n",a);
  a=(a%10)*1000+(a/10);
  printf("%4d\n",a);
  a=(a%10)*1000+(a/10);
  printf("%4d\n",a);
  a=(a%10)*1000+(a/10);
  printf("%4d\n",a);
  return 0;
}
