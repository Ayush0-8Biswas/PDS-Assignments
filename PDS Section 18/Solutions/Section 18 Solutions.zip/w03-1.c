#include<stdio.h>

int main()
{
  int date, month, year, isvalid=1, offset=0;

  //Bullet 1
  
  printf("Enter date: ");
  scanf("%d",&date);
 
/*In my system, size of int is 4 bytes. This is enough to hold any 8 digit integer.
  If size of int is smaller in your system (eg. 2 bytes), you may need to use long int or long long int. */

  year=date%10000;
  date/=10000;
  month=date%100;
  date/=100;

/* Note that the variable date holds the value of day at this point. */

  //Bullet 2

  printf("Day: %d\nMonth: %d\nYear: %d\n", date, month, year);

  //Bullet 3

  if(year<2021)
  {
    printf("Before 2021\n");
    return 0;
  }
  if(year>2099)
  {
    printf("After 2099\n");
    return 0;
  }

  //Bullet 4
 
  if(month<1 || month>12)
  {
    printf("Month out of range.\n");
    return 0;
  }
  if(date<1 || date > 31)
  {
    printf("Day out of range.\n");
    return 0;
  }
  switch(month)
  {
    case 2: if(date>28+(!(year%4))) isvalid=0; break;
    case 4: 
    case 6:
    case 9:
    case 11: if(date>30) isvalid=0;
  }
  if(!isvalid)
  {
    printf("Day out of range.\n");
    return 0;
  }

  //Bullet 5 

  offset=(year-2021)*365+(year-2021)/4;

  switch(month)
  {
    case 12: offset+=30; //Adding number of days in November. Similarly for other cases.
    case 11: offset+=31;
    case 10: offset+=30;
    case 9: offset+=31;
    case 8: offset+=31;
    case 7: offset+=30;
    case 6: offset+=31;
    case 5: offset+=30;
    case 4: offset+=31;
    case 3: offset+=28+(!(year%4));
    case 2: offset+=31;
  }
  
  offset+=date-1;

  switch(offset%7)
  {
    case 0: printf("It's a Friday of "); break;
    case 1: printf("It's a Saturday of "); break;
    case 2: printf("It's a Sunday of "); break;
    case 3: printf("It's a Monday of "); break;
    case 4: printf("It's a Tuesday of "); break;
    case 5: printf("It's a Wednesday of "); break;
    case 6: printf("It's a Thursday of "); break;
  }
  
  switch(month)
  {
    case 1: printf("January.\n"); break;
    case 2: printf("February.\n"); break;
    case 3: printf("March.\n"); break;
    case 4: printf("April.\n"); break;
    case 5: printf("May.\n"); break;
    case 6: printf("June.\n"); break;
    case 7: printf("July.\n"); break;
    case 8: printf("August.\n"); break;
    case 9: printf("September.\n"); break;
    case 10: printf("October.\n"); break;
    case 11: printf("November.\n"); break;
    case 12: printf("December.\n"); break;
  }

   
  return 0;
}
