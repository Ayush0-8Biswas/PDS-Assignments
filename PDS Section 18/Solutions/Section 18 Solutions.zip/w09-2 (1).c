#include<stdio.h>

typedef struct {
int coeff;
int expx;
int expy;
} term;

int less(term t1, term t2)
{
  if(t1.expx<t2.expx)
    return 1;
  if(t1.expx>t2.expx)
    return 0;
  if(t1.expy<t2.expy)
    return 1;
  return 0;
}

int insert(int n1, term p1[], term newterm)
{
  int i, j;
  for(i=0; i<=n1; i++)
     {
       if(p1[i].expx==newterm.expx && p1[i].expy==newterm.expy)
       {
         p1[i].coeff+=newterm.coeff;
         if(p1[i].coeff==0)
         {
           for(j=i; j<n1; j++)
             p1[j]=p1[j+1];
           n1--;
         }
         break;
       }
       if(less(newterm, p1[i]) || i==n1)
       {
         for(j=n1-1; j>=i; j--)
           p1[j+1]=p1[j];
         p1[i]=newterm;
         n1++;
         break;
       }
     }
  return n1;
}

int Add(term sum[], term p1[], term p2[], int n1, int n2)
{
  int i=0, j=0, k=0;
  while(i!=n1 && j!=n2)
  {
    if(p1[i].expx==p2[j].expx && p1[i].expy==p2[j].expy)
    {
      sum[k]=p1[i];
      sum[k].coeff=p1[i++].coeff+p2[j++].coeff;
      if(sum[k].coeff!=0)
        k++;
    }
    else if(less(p1[i], p2[j]))
      sum[k++]=p1[i++];
    else if(less(p2[j], p1[i]))
      sum[k++]=p2[j++];
  }
  for(;i<n1;i++)
    sum[k++]=p1[i];
  for(;j<n2;j++)
    sum[k++]=p2[j];
  return k;
}

int main()
{
  int r, n1=0, n2=0, i, j, n;
  term p1[10], p2[10], sum[10], newterm;
  printf("Input polynomial 1:\n");
  while(1)
  {
     printf("Enter exponent of x, exponent of y and coefficient: ");
     scanf("%d%d%d", &newterm.expx, &newterm.expy, &newterm.coeff);
     if(newterm.coeff==0)
       break;
     n1=insert(n1, p1, newterm);     
   }
  printf("Polynomial 1: \n");
  for(i=0; i<n1; i++)
    printf("(%d, %d, %d)\n", p1[i].expx, p1[i].expy, p1[i].coeff);
  printf("Input polynomial 2:\n");
  while(1)
  {
     printf("Enter exponent of x, exponent of y and coefficient: ");
     scanf("%d%d%d", &newterm.expx, &newterm.expy, &newterm.coeff);
     if(newterm.coeff==0)
       break;
     n2=insert(n2, p2, newterm); 
   }
   printf("Polynomial 2: \n");
   for(i=0; i<n2; i++)
    printf("(%d, %d, %d)\n", p2[i].expx, p2[i].expy, p2[i].coeff);
   n=Add(sum, p1, p2, n1, n2);
   printf("Sum: \n");
   for(i=0; i<n; i++)
     printf("(%d, %d, %d)\n", sum[i].expx, sum[i].expy, sum[i].coeff);
   return 0;
}
