#include<stdio.h>

int main()
{
  int i;
  float a, b, x;

  //Bullet 1

  printf("Enter a: ");
  scanf("%f",&a);

  //Bullet 2
  
  printf("a=%0.4f\n", a);
  b=a;

  //The next 4 lines raise b to its 16th power

  b=b*b;
  b=b*b;
  b=b*b;
  b=b*b;

  //Bullet 3

  x=(1-b)/(1-a);
  printf("p(a)=%0.4f\n",x);

  //Bullet 4

  x=(1-b)/((1-a)*(1-a)) - 16*b/(1-a);
  printf("q(a)=%0.4f\n",x);
  
  //Bullet 5

  x=1/(1-a);
  printf("r(a)=%0.4f\n",x);
  return 0;
}
