#include<stdio.h>
#include<stdlib.h>


int Ispresent(int V[], int i, int x, int y)
{
  while(i>0)
  {
    if(V[i-1]==y && V[i-2]==x)
      return 1;
    i-=2;
  }
  return 0;
}



int main()
{
  int seed, i, n, x, y, V[800];
  printf("Enter number of points: ");
  scanf("%d",&n);
  printf("Enter seed: ");
  scanf("%d",&seed);
  srand(seed);
  for(i=0; i<2*n;)
  {
    x=rand()%21;
    y=rand()%21;
    if(!Ispresent(V, i, x, y))
    {
      V[i]=x;
      V[i+1]=y;
      i=i+2;
    }
   }
   printf("Unique points generated: \n");
   for(i=0; i<2*n; i+=2)
     printf("%2d %2d\n", V[i], V[i+1]);
   return 0;
}
