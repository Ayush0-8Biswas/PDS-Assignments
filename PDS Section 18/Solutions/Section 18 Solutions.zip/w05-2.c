#include<stdio.h>
int main()
{
  int a, b, c, d, e, f, i, n, A[400];
  printf("Enter numerator and denominator of fraction 1 in reduced form: ");
  scanf("%d%d", &a, &b);
  printf("Enter numerator and denominator of fraction 2 in reduced form: ");
  scanf("%d%d", &c, &d);
  printf("Enter number of fractions: ");
  scanf("%d", &n);
  A[0]=a;
  A[1]=b;
  printf("\n");
  for(i=1; i<=2*n; i+=2)
  {
    e=a+c;
    f=b+d;
    printf("Fraction %d: %d/%d\n", i/2+1, e, f);    

    // Compute GCD of e and f

    while(f!=0)
    {
      e=e%f;
      e=e-f;
      f=e+f;
      e=f-e;
    }
    printf("GCD of numerator and denominator=%d\n", e);

    // End of GCD computation

    a=(a+c)/e;
    b=(b+d)/e;
    printf("Fraction %d in reduced form =%d/%d\n\n", i/2+1, a, b);
    A[i+1]=a;
    A[i+2]=b;
  }
  A[2*n+2]=c;
  A[2*n+3]=d;
  printf("All fractions:\n");
  for(i=0;i<2*n+4; i+=2)
    printf("%d/%d\n",A[i], A[i+1]);
  return 0;
}
