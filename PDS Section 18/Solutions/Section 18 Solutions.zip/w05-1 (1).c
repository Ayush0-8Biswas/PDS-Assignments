#include<stdio.h>

int main()
{
  int choice, i, j, size=0, A[100], num, num_l, num_r, l, r, mid;
  while(1)
  {
    printf("\n1. Insert\n2. Delete numbers in a range\n3. Search\n4. Display\n5. Exit\n\nEnter an option: ");
    scanf("%d",&choice);
    switch(choice)
    {
      case 1:

        //Is the database full?

        if(size==100)
        {
          printf("Database full!");
          break;
        } 
        printf("Enter number: ");
        scanf("%d", &num);

        // Is the database empty?

        if(size==0)
        {
          A[size++]=num;
          break;
        }

        // Finding the first element that is at least the input (if such an element exists)

        l=0;
        r=size-1;
        while(l<r)
        {
          mid=(l+r)/2;
          if(A[mid]<num)
            l=mid+1;
          else
            r=mid;
        }
        
        // Are all the elements less than the input?
         
        if(A[l]<num)
        {
           A[size++]=num;
           break;
        }        

        // Does the input already exist in the database?

        if(A[l]==num)
        {
          printf("Number exists!\n");
          break;
        }

        // Insert input

        for(i=size; i>l; i--)
          A[i]=A[i-1];
        A[l]=num;
        size++;
        break;

      case 2: 

       //Is the database empty?

        if(size==0)
        {
          printf("Database empty!\n");
          break;
        }

       //Taking the range as input

        printf("Enter lower limit: ");
        scanf("%d", &num_l);
        printf("Enter upper limit: ");
        scanf("%d", &num_r);

       // Finding the first number that is at least the lower limit (if such a number exists)

        l=0;
        r=size-1;
        while(l<r)
        {
          mid=(l+r)/2;
          if(A[mid]<num_l)
            l=mid+1;
          else
            r=mid;
        }
        i=l;

        // Are all numbers less than the lower limit?

        if(A[i]<num_l)
        {
          printf("No number in the given range\n");
          break;
        }

        // Checking if the last element is in the range

        if(A[size-1]<=num_r)
        {
          size=i;
          break;
        }

        // Finding the first number strictly larger than the upper limit

        l=0;
        r=size-1;
        while(l<r)
        {
          mid=(l+r)/2;
          if(A[mid]<=num_r)
            l=mid+1;
          else
            r=mid;
        }
        j=l;

        // Checking if it is an empty interval

        if(j==i)
        {
          printf("No number in the given range\n");
          break;
        }

        // Deleting numbers in the range

        for(;j<size;i++,j++)
          A[i]=A[j];
        size-=j-i;
        break;

      case 3:
        if(size==0)
        {
           printf("Database empty.\n");
           break;
        }
        printf("Enter number: ");
        scanf("%d",&num);
        l=0;
        r=size-1;
        while(l<r)
        {
          mid=(l+r)/2;
          if(A[mid]<num)
            l=mid+1;
          else
            r=mid;
        }
        if(A[l]==num)
          printf("Number exists.\n");
        else
          printf("Number does not exist.\n");
        break;

      case 4:
        if(size==0)
        {
           printf("Database empty.\n");
           break;
        }
        printf("Numbers in the database:\n");
        for(i=0; i<size; i++)
          printf("%d\n", A[i]);
        break;

      case 5: return 0;

      default: printf("Enter a valid option\n");
    }
  }
}
