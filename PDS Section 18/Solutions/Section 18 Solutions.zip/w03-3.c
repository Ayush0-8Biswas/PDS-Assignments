#include<stdio.h>

int main(){
  int a, b, c; 
  
  printf("Enter a and b: "); 
  scanf("%d%d", &a, &b);
  
  if(b>0) printf("[%d; ", a/b); else {printf("\b\b]\n"); return 0;}
  c = a%b; 
  a = b, b = c;
  if(b>0) printf("%d, ", a/b); else {printf("\b\b]\n"); return 0;}
  c = a%b; 
  a = b, b = c;
  if(b>0) printf("%d, ", a/b); else {printf("\b\b]\n"); return 0;}
  c = a%b; 
  a = b, b = c;
  if(b>0) printf("%d, ", a/b); else {printf("\b\b]\n"); return 0;}
  c = a%b; 
  a = b, b = c;
  if(b>0) printf("%d, ", a/b); else {printf("\b\b]\n"); return 0;}
  
//   If it has more than 5 terms:  
//   c = a%b; 
//   a = b, b = c;
//   if(b>0) printf("%d, ", a/b); else {printf("\b\b]\n"); return 0;}
//
//   And so on... => Loop! (Yet to be covered) 

  printf("\b\b]\n");
  return 0;
}
