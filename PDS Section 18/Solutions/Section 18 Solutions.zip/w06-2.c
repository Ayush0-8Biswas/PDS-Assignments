#include<stdio.h>

int Intersect(int l1x, int l1y, int l2x, int l2y, int r1x, int r1y, int r2x, int r2y)
{
  float x, y, delta_lx, delta_ly, delta_rx, delta_ry, delta_slope;
  delta_lx=l1x-l2x;
  delta_ly=l1y-l2y;
  delta_rx=r1x-r2x;
  delta_ry=r1y-r2y;
  if(delta_lx*delta_ry==delta_rx*delta_ly)  // if same slope then no intersection
    return 0;

  /* If segment l is vertical */

  if(delta_lx==0)
  {
    y=r1y+(l1x-r1x)*delta_ry/delta_rx;
    if((y>=l1y && y <=l2y) || (y>=l2y && y <=l1y))
      return 1;
    else return 0;
  }

  /* If segment r is vertical */

  if(delta_rx==0)
  {
    y=l1y+(r1x-l1x)*delta_ly/delta_lx;
    if((y>=r1y && y <=r2y) || (y>=r2y && y <=r1y))
      return 1;
    else return 0;
  }

  /* If none of the segments is vertical */

  delta_slope = delta_ly/delta_lx - delta_ry/delta_rx;
  x=(r1y-l1y-r1x*delta_ry/delta_rx + l1x*delta_ly/delta_lx)/delta_slope;
  y=r1y+delta_ry*(x-r1x)/delta_rx;
  if (!((l1x <= x && x <= l2x) || (l2x <= x && x <= l1x)))  // Does (x, y) lie on l?
    return 0;
  if (!((r1x <= x && x <= r2x) || (r2x <= x && x <= r1x)))  // Does (x, y) lie on r?
   return 0;
  return 1;  
}



int main()
{
  int n, i, j, intersect=0;
  int P[200];
  printf("How many vertices? ");
  scanf("%d",&n);
  
  printf("Enter X and Y co-ordinates:\n");

  for(i=0; i<2*n; i+=2)
  {
    scanf("%d%d", &P[i], &P[i+1]);
  }
  for(i=0; i<2*n-4; i+=2)
    for(j=i+4; j<2*n-2; j+=2)
      if(Intersect(P[i], P[i+1], P[i+2], P[i+3], P[j], P[j+1], P[j+2], P[j+3]))
        intersect+=1;
        
  for(i=2; i<2*n-4; i+=2)
    if(Intersect (P[2*n-2], P[2*n-1], P[0], P[1], P[i], P[i+1], P[i+2], P[i+3]))
      intersect+=1;
  if(intersect==0)
    printf("Polygon is a simple polygon.\n");
  else
    printf("Polygon is a not simple polygon.\nNumber of intersecting pairs of non-adjacent sides is %d.\n", intersect);
  return 0;
}
