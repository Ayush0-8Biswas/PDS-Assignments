#include<stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct student
{
  char name[100];
  char roll[10];
} *std;


int prefixmatch(char *roll, char *s)
{
  int i=0;
  while(s[i]!='\0')
  {
    if(roll[i]!=s[i])
      return 0;
    i++;
  }
  return 1;
}


int binsearch(std studlist, int l, int r, char s[])
{
  int mid;
  if(l==r)
    return l;
  mid=(l+r)/2;
  if(strcmp(s, studlist[mid].roll)<=0)
    binsearch(studlist, l, mid, s);
  else binsearch(studlist, mid+1, r, s);
}


int main()
{
  int n, i;
  std studlist;
  char s[100];
  
  printf("How many students? ");
  scanf("%d",&n);
  studlist=(std)malloc(n*sizeof(struct student));
  
  printf("Enter roll numbers and names (sorted by roll number):\n");
  for(i=0; i<n; i++){
    scanf("%s ",studlist[i].roll);
    scanf("%[^\n]s",studlist[i].name);
  }
  
  printf("\nEnter prefix: ");
  scanf("%s", s);
  
  i=binsearch(studlist, 0, n-1, s);
  if(!prefixmatch(studlist[i].roll, s)){ 
    printf("None found!\n");
    return 1;
  }
  
  printf("\nFound:\n");
  for(; prefixmatch(studlist[i].roll, s) && i<n; i++)
    printf("%s %s\n", studlist[i].roll, studlist[i].name);
  return 0;
}
