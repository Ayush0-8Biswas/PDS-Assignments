/* Name: Aritra Basu
   Roll number: 17AG21015
*/

#include <stdio.h>

int main(){
  printf("Name: Aritra Basu\nRoll number: 17AG21015\n\n");
  return 0;
}

