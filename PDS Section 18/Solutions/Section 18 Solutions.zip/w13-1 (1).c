#include<stdio.h>
#include<stdlib.h>

typedef struct node{
int x;
int y;
struct node *next;} point;

void insert(point **list, point P)
{
  point *t=(point*)malloc(sizeof(point));
  t->x=P.x;
  t->y=P.y;
  t->next=(*list);
  (*list)=t;
}

void deletehead(point **list)      //Assumes that the list is not empty
{
  point *T=(*list);
  (*list)=(*list)->next;
  free(T);
}

int isrightturn(point *P, point *Q, point *R)
{
  int a0, b0, a1, b1;
  b0=(Q->x)-(P->x);
  a0=(Q->y)-(P->y);
  b1=(R->x)-(Q->x);
  a1=(R->y)-(Q->y);
  return (a1*b0-a0*b1 > 0);
}

void getnextpoint(point *T, int **A, int *a, int r)
{
  int i;
  (*a)++;
  for(;;(*a)++)
  {
    for(i=0; i<r; i++)
    {
      if(A[i][*a]==2)
      {
        T->x=i;
        T->y=(*a);
        return;
      }
    }
  }
}

void printlist(point *list)
{
  while(list!=NULL)
  {
    printf("(%d, %d) ", list->y, list->x);
    list=list->next;
  }
}


int main()
{
  int r, c, t, i, j, k, **A;  
  unsigned int s;
  point T1, T2, *list=NULL;  

  // PART a

  printf("Enter no. of rows, no. of columns and expected percentage of 1's: ");
  scanf("%d%d%d", &r, &c, &t);
  A=(int **)malloc(r*sizeof(int *));
  for(i=0; i<r; i++)
    A[i]=(int *) malloc(c*sizeof(int));
  A[0][0]=A[0][c-1]=1;
  printf("Enter seed: ");
  scanf("%u", &s);
  srand(s);
  printf("\nInput array: \n");
  for(i=0; i<r; i++)
    for(j=0; j<c; j++)
      if(!((i==0 && j==0) || (i==0 && j==c-1)))
        (rand()%100 + 1 <= t)? (A[i][j]=1): (A[i][j]=0);
  for(i=r-1; i>=0; printf("\n"),i--)
    for(j=0; j<c; j++)
      (A[i][j]==0)? (printf("- ")): printf("1 ");
  
  // PART b

  printf("\nList of points: \n");
  printf("(0, 0) ");
  for(j=0; j<c; j++)
  {
    k=-1;
    for(i=0; i<r; i++)
    {
      if(A[i][j]==1)
        k=i;
    }
    if(k!=-1 && !(k==0 && j==0))
    {
      A[k][j]=2;
      printf("(%d, %d) ", j, k);
    }
  }
  if(A[0][c-1]!=2)
    printf("(0, %d)", c-1);
  printf("\n");

  //A[0][0] will be set to 2 later. //
  
  //PART c

  T1.x=0;
  T1.y=0;
  insert(&list, T1);
  j=-1;  
  getnextpoint(&T1, A, &j, r); //Gets the next point from P
  insert(&list, T1);
  A[0][0]=2;
  while(j!=c-1)
  {
    getnextpoint(&T1, A, &j, r);
    while(list->next!=NULL)
    {
      if(isrightturn(list->next, list, &T1))
        break;
      A[list->x][list->y]=1; //Handling a non-vertex in P
      deletehead(&list);
    }
    insert(&list, T1);
  }
  if(!(list->x==0 && list->y==c-1))
  {
    T1.x=0;
    T1.y=c-1;
    insert(&list, T1);
    A[0][c-1]=2;
  }
  printf("\nVertices: \n");
  printlist(list);
  printf("\n\nOutput array: \n");
  for(i=r-1; i>=0; printf("\n"),i--)
    for(j=0; j<c; j++)
      (A[i][j]==0)? (printf("- ")): printf("%d ", A[i][j]);
  return 0;
}
