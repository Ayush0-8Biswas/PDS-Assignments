// <Your Name>
// <Your Roll Number>

#include <stdio.h>

int main(){
  int a, b;
  
  printf("Enter a and b: ");
  scanf("%d%d", &a, &b);
  
  printf("a/b = %f\n", (float)a/(float)b);
    
  return 0;
}

