#include<stdio.h>

int main()
{
//Triangle

printf("    *    \n   * *   \n  *   *  \n *     * \n*********\n\n\n");

//Swastika

printf("**   *******\n**   *******\n**   **\n**   **\n************\n************\n     **   **\n     **   **\n     **   **\n*******   **\n*******   **");

return 0;

}
