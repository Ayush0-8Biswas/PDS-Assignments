#include<stdio.h>

int main(){
  char P[1000];
  int line=0, word=0, stanza=0, punc=0, i=0;
  printf("Enter a poem with its name and poet: \n");
  scanf("%[^#]s", P);
  
  printf("\nPoem name: ");
  do
    printf("%c", P[i++]);
  while(P[i]!='\n');
  i++; //skip the blank line
  
  printf("\nPoet name: ");
  do
    printf("%c", P[++i]);
  while(P[i]!='\n');
  i++; //skip the blank line
  
  do{    
    if(P[i]=='\n'){
      i++, stanza++;
      continue;
    }
    
    do{ //scan a word
      i++; 
    } while(!(P[i] == ' ' || P[i] == '\n'));
    
    word++;
    
    if(P[i] == '\n')
      line++;
    
    if(P[i-1]=='.' || P[i-1]==',' || P[i-1]==':' || P[i-1]==';' || P[i-1]=='!' || P[i-1]=='?')
      punc++;
    
    i++;
  } while(P[i]!='\0');
  
  printf("\nLines: %d\nWords: %d\nStanzas: %d\nPunctuation marks: %d\n", line, word, stanza, punc);
  
  return 0;
}
