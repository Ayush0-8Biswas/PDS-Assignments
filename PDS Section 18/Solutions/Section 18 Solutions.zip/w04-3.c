// Integer points on a straight line segment with integer endpoints.

#include <stdio.h>

int main(){
  int x1, y1, x2, y2;
  int a, b, c, i, x, y, dx, dy;
  printf("Enter (x,y) coordinates of Point p: ");
  scanf("%d%d", &x1, &y1);
  printf("Enter (x,y) coordinates of Point q: ");
  scanf("%d%d", &x2, &y2);
  
  a = x2 - x1; 
  b = y2 - y1;
  if (a<0) a = -a;
  if (b<0) b = -b;
  
  while(b!=0){ // find GCD(a,b)
    c = b; 
    b = a%b;
    a = c; 
  } 
  // The variable a finally contains the GCD - it's so cute! Right?
  
  printf("Number of integer points on the line segment pq = %d.\n", a+1); 
  
  dx = (x2 - x1)/a, dy = (y2 - y1)/a;
  
  printf("Integer points on the line segment pq:\n"); 
  for(x=x1, y=y1, i=0; i<a+1; i++){
    printf("%4d: (%d,%d)\n", i+1, x, y);
    x += dx, y+= dy;
  }
  
  return 1;
}
