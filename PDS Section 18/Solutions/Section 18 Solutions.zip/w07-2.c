#include<stdio.h>
int count=1;

void print_paths(int A[], int current, int x1, int y1, int x2, int y2)
{
  int i;
  if(!((x1<=x2) && (y1<=y2)))
    return;
  if(x1==x2 && y1==y2)
  {
    printf("%d. ", count++);
    for(i=0; i<current; i+=2)
      printf("(%d, %d), ", A[i], A[i+1]);
    printf("(%d, %d)\n", x2, y2);
    return;
  }
  A[current+1]=x1;
  A[current+2]=y1;
  print_paths(A, current+2, x1+1, y1, x2, y2);
  print_paths(A, current+2, x1, y1+2, x2, y2);
  print_paths(A, current+2, x1+1, y1+1, x2, y2);
  return;
}



int main()
{
  int A[100], n;
  printf("Enter the value of n: ");
  scanf("%d", &n);
  print_paths(A, -1, 0, 0, n, n);
  return 0;
}
