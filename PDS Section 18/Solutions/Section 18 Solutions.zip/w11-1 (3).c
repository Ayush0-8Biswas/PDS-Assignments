#include<stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct student{
  char roll[10];
  char name[100];
} *std;


void swap(std A, std B){
  struct student temp;
  temp=*A;
  (*A)=(*B);
  (*B)=temp;
}


int main(){
  int n, i, j, b;
  struct student temp;
  std studlist;
  
  printf("How many students? ");
  scanf("%d", &n);
  studlist=(std)malloc(n*sizeof(struct student));
  
  printf("Enter roll numbers and names:\n");
  for(i=0; i<n; i++)
    scanf("%s%[^\n]s", studlist[i].roll, studlist[i].name);    
  
  printf("\nEnter 1 to sort by roll number, 0 to sort by name: ");
  scanf("%d", &b);
  
  for(i=n-2; i>=0; i--)
    for(j=0; j<=i; j++)
      if((b)? (strcmp(studlist[j].roll, studlist[j+1].roll)>0) : (strcmp(studlist[j].name, studlist[j+1].name)>0))
        swap(studlist+j, studlist+j+1);
      
   printf("After sorting by %s:\n\n", (b==1)? "roll number" : "name");
   for(i=0; i<n; i++)
     printf("%3d. %9s %s\n", i+1, studlist[i].roll, studlist[i].name);
   
   return 0;
}

