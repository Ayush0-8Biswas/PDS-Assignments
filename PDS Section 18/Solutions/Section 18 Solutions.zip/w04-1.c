// Continued fraction for a/b.

#include<stdio.h>

int main(){
  int a, b, c=0; 
  
  printf("Enter a and b: "); 
  scanf("%d%d", &a, &b);
  
  do{
    if(c==0)
      printf("Continued fraction = [%d; ", a/b); 
    else  
      printf("%d, ", a/b); 
    c = a%b; 
    a = b, b = c;
  }while(a>1 && b>0);
  
  printf("\b\b].\n");
  return 0;
}
