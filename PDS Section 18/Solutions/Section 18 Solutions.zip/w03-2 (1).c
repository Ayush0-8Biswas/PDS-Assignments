#include<stdio.h>

int main()
{
  int sn, q;
  float basic_price, price;
  printf("Following are 12 items and their rates (INR):\n\n");
  printf("SN      ITEM                 RATE\n");
  printf("--      ----                 ----\n\n");
  printf("01:     BUTTER COOKIES       25\n");
  printf("02:     CASHEW COOKIES       30\n");
  printf("03:     CREAM CAKE           22\n");
  printf("04:     LEMON JUICE          35\n");
  printf("05:     VEG CASHEW CAKE      18\n");
  printf("06:     MANGO JUICE          78\n");
  printf("07:     COOKIES (PLAIN)      15\n");
  printf("08:     ORANGE JUICE         73\n");
  printf("09:     MILK BISCUITS        12\n");
  printf("10:     PLAIN VEG CAKE       20\n");
  printf("11:     BUTTER FRUIT CAKE    25\n");
  printf("12:     PINEAPPLE JUICE      65\n\n");
  printf("Enter the Serial Number (SN) of item and the quantity you want: ");
  scanf("%d%d",&sn,&q);
  printf("Your item is ");
  switch(sn)
  {
    case 1: printf("BUTTER COOKIES x"); basic_price=25.0; break;
    case 2: printf("CASHEW COOKIES x"); basic_price=30.0; break;
    case 3: printf("CREAM CAKE x"); basic_price=22.0; break;
    case 4: printf("LEMON JUICE x"); basic_price=35.0; break;
    case 5: printf("VEG CASHEW CAKE x"); basic_price=18.0; break;
    case 6: printf("MANGO JUICE x"); basic_price=78.0; break;
    case 7: printf("COOKIES (PLAIN) x"); basic_price=15.0; break;
    case 8: printf("ORANGE JUICE x"); basic_price=73.0; break;
    case 9: printf("MILK BISCUITS x"); basic_price=12.0; break;
    case 10: printf("PLAIN VEG CAKE x"); basic_price=20.0; break;
    case 11: printf("BUTTER FRUIT CAKE x"); basic_price=25.0; break;
    case 12: printf("PINEAPPLE JUICE x"); basic_price=65.0;
  }
  printf(" %d\n", q);
  printf("Basic price = Rs. %7.2f\n", basic_price*q);
  printf("Tax @12.5%%  = Rs. %7.2f\n", basic_price*q*0.125);
  printf("Total price = Rs. %7.2f\n", price=basic_price*q*1.125);

  /* We may have used basic_price itself in place of price. 
     However, in the interest of readability we preferred that 
     the variable basic_price be reserved for holding the basic price. */

  printf("=========================\n");
  printf("To pay      = Rs. %4d.00", (int)(price+0.50));
  printf("\n=========================");
  printf("\nThank you!\nPlease visit us again.\n");
  return 0;
}
