// <Your Name>
// <Your Roll Number>

#include <stdio.h>

int main(){
  float x, y;
  
  printf("Enter x: ");
  scanf("%f", &x);
  
  y = 1 + x + x*x; 
  
  printf("Answer = %12.10f\n", y); 
    
  return 0;
}

