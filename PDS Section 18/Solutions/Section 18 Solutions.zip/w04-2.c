/* 
   Solving a cubic polynomial, given: 
1) all coefficients are integers in [-5, 5].
2) x^3 coefficient is non-zero.
*/

#include<stdio.h>

int main()
{
  int i, c3, c2, c1, c0;
  double a=-15.0, b=15.0, c;
  double fa, fb, fc;
  printf("Enter coefficient of x^0: ");
  scanf("%d", &c0);
  printf("Enter coefficient of x^1: ");
  scanf("%d", &c1);
  printf("Enter coefficient of x^2: ");
  scanf("%d", &c2);
  printf("Enter coefficient of x^3: ");
  scanf("%d", &c3);
  fa=c0+a*(c1+a*(c2+a*c3));
  fb=c0+b*(c1+b*(c2+b*c3));
  while(1)
  {
    c=(a*fb-b*fa)/(fb-fa);
    fc=c0+c*(c1+c*(c2+c*c3));
    if(fc<=0.001 && fc>=-0.001)
    {
      printf("Root of the polynomial: %f\n", c);
      return 0;
    }   
    if(fa*fc<0)
    {
      b=c;
      fb=fc;
    }
    else
    {
      a=c;
      fa=fc;
    }
  }
  return 0;
}
